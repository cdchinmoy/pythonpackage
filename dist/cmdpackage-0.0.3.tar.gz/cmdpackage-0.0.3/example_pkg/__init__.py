import sys
import datetime 
import calendar 
  
program_name = sys.argv[0]
arguments = sys.argv[1:]
ddate = arguments[0]
  
def findDay(date): 
    born = datetime.datetime.strptime(date, '%d-%m-%Y').weekday() 
    return (calendar.day_name[born]) 
  
print(findDay(ddate)) 