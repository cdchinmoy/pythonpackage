import sys
import datetime 
import calendar 

class FindDay:

    def __init__(self, date): 
        born = datetime.datetime.strptime(date, '%d-%m-%Y').weekday() 
        return (calendar.day_name[born]) 